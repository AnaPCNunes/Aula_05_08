class Produto:
    def __init__(self, cod, descricao, valor, quantidade):
        self.cod = cod
        self.descricao = descricao
        self.valor = valor
        self.quantidade = quantidade
