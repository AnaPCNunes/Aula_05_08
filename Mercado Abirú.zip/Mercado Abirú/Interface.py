from tkinter import *
import posiciona

class Modulo1:
    def __init__(self):
        self.window = Tk()

        self.window.geometry('990x600+200+200')
        self.window.title('Supermercado Abirú')
        self.window.resizable(width=False, height=False)
        
        #===============================================| Função posiciona |======================================================
        self.window.bind('<Button-1>', posiciona.inicio_place)
        self.window.bind('<ButtonRelease-1>', lambda arg: posiciona.fim_place(arg, self.window))
        self.window.bind('<Button-2>', lambda arg: posiciona.para_geometry(self.window))

        #================================================| Imagens Gerais |=======================================================
        self.bVoltar = PhotoImage(file='Imagens/botaoVolta.png')

        self.bSalvar = PhotoImage(file='Imagens/botaoSalvar.png')

        # ========================================| Imagens Primeiro Frame (Login) |==============================================
        self.login = PhotoImage(file='Imagens/Login.png')
        
        self.bLogin = PhotoImage(file='Imagens/botaoLogin.png')

        # =========================================| Imagens Segundo Frame (Menu) |===============================================
        self.menu = PhotoImage(file='Imagens/Menu.png')

        self.bCad = PhotoImage(file='Imagens/botaoCadastro.png')

        self.bAlt = PhotoImage(file='Imagens/botaoAlterar.png')

        self.bExc = PhotoImage(file='Imagens/botaoExcluir.png')

        #========================================| Imagens Terceiro Frame (Cadastro) |============================================
        self.cad = PhotoImage(file='Imagens/Cadastro.png')

        #=========================================| Imagens Quarto Frame (Alteração) |============================================
        self.alt = PhotoImage(file='Imagens/TelaAlteração.png')

        self.bSeguir = PhotoImage(file='Imagens/botaoSeguir.png')

        self.bPesquisa = PhotoImage(file='Imagens/BotaoPesquisa.png')

        #======================================| Imagens Quinto Frame (Alteração pt 2) |==========================================
        self.alt2 = PhotoImage(file='Imagens/Alteração2.png')

        #===========================================| Imagens Sexto Frame (Excluir) |=============================================
        self.exc = PhotoImage(file='Imagens/TelaExcluir.png')

        self.bConfir = PhotoImage(file='Imagens/botaoConfirmar.png')

        #==================================================| Criação de Frames |==================================================
        self.f1 = Frame(self.window)
        self.f1.pack()
        self.f2 = Frame(self.window)
        self.f3 = Frame(self.window)
        self.f4 = Frame(self.window)
        self.f5 = Frame(self.window)
        self.f6 = Frame(self.window)

        #========================================================| Login |========================================================
        self.lLogin = Label(self.f1, image=self.login)
        self.lLogin.pack()

        self.b1 = Button(self.f1, bd=0, image=self.bLogin, command=self.tMenu)
        self.b1.place(width=303, height=90, x=580, y=394)

        self.ent1 = Entry(self.f1, bd=0, bg='#EBE7D9', fg='#342F4B', justify='center', font='Lato 15')
        self.ent1.place(width=245, height=23, x=607, y=309)

        self.ent1.insert(0, "R.A.")
        self.ent1.configure(state=DISABLED)

        def on_click(event):
            self.ent1.configure(state=NORMAL)
            self.ent1.delete(0, END)

            # make the callback only work once
            self.ent1.unbind('<Button-1>', on_click_id)

        on_click_id = self.ent1.bind('<Button-1>', on_click)

        #========================================================| Menu |=========================================================
        self.lMenu = Label(self.f2, image=self.menu)
        self.lMenu.pack()

        self.b3 = Button(self.f2, bd=0, image=self.bVoltar, command=lambda: [self.f2.forget(), self.f1.pack()])
        self.b3.place(width=72, height=65, x=4, y=7)

        self.b2 = Button(self.f2, bd=0, image=self.bCad, command=self.tCadastro)
        self.b2.place(width=308, height=50, x=342, y=200)

        self.b4 = Button(self.f2, bd=0, image=self.bAlt, command=self.tAlterar)
        self.b4.place(width=308, height=50, x=342, y=300)

        self.b5 = Button(self.f2, bd=0, image=self.bExc, command=self.tExcluir)
        self.b5.place(width=308, height=50, x=342, y=405)

        #===================================================| Cadastro de Produto |==============================================
        self.lCad = Label(self.f3, image=self.cad)
        self.lCad.pack()

        self.b6 = Button(self.f3, bd=0, image=self.bVoltar, command=lambda: [self.f3.forget(), self.f2.pack()])
        self.b6.place(width=72, height=65, x=4, y=7)

        self.ent2 = Entry(self.f3, bd=0, bg='#EBE7D9', fg='#342F4B', justify='center', font='Lato 14')
        self.ent2.place(width=262, height=26, x=363, y=183)

        self.ent3 = Entry(self.f3, bd=0, bg='#EBE7D9', fg='#342F4B', justify='center', font='Lato 14')
        self.ent3.place(width=261, height=27, x=364, y=292)

        self.ent4 = Entry(self.f3, bd=0, bg='#EBE7D9', fg='#342F4B', justify='center', font='Lato 14')
        self.ent4.place(width=262, height=26, x=364, y=401)

        self.b7 = Button(self.f3, bd=0, image=self.bSalvar)
        self.b7.place(width=275, height=80, x=360, y=492)

        #=================================================| Alteração de Produto |================================================
        self.lAlt = Label(self.f4, image=self.alt)
        self.lAlt.pack()

        self.b7 = Button(self.f4, bd=0, image=self.bVoltar, command=lambda: [self.f4.forget(), self.f2.pack()])
        self.b7.place(width=72, height=65, x=4, y=7)

        self.ent5 = Entry(self.f4, bd=0, bg='#EBE7D9', fg='#342F4B', justify='left', font='Lato 14')
        self.ent5.place(width=225, height=25, x=363, y=166)

        self.b8 = Button(self.f4, bd=0, image=self.bSeguir, command=self.tAlterar2)
        self.b8.place(width=275, height=80, x=360, y=494)

        self.bt = Button(self.f4, bd=0, image=self.bPesquisa)
        self.bt.place(width=48, height=34, x=592, y=162)

        #======================================================| Alteração 2 |====================================================
        self.lAlt2 = Label(self.f5, image=self.alt2)
        self.lAlt2.pack()

        self.b9 = Button(self.f5, bd=0, image=self.bVoltar, command=lambda: [self.f5.forget(), self.f4.pack()])
        self.b9.place(width=72, height=65, x=4, y=7)

        self.ent6 = Entry(self.f5, bd=0, bg='#EBE7D9', fg='#342F4B', justify='center', font='Lato 14')
        self.ent6.place(width=261, height=24, x=364, y=225)

        self.ent7 = Entry(self.f5, bd=0, bg='#EBE7D9', fg='#342F4B', justify='center', font='Lato 14')
        self.ent7.place(width=261, height=24, x=364, y=361)

        self.b10 = Button(self.f5, bd=0, image=self.bSalvar)
        self.b10.place(width=275, height=80, x=360, y=494)

        #====================================================| Excluir Produto |==================================================
        self.lExc = Label(self.f6, image=self.exc)
        self.lExc.pack()

        self.b11 = Button(self.f6, bd=0, image=self.bVoltar, command=lambda: [self.f6.forget(), self.f2.pack()])
        self.b11.place(width=72, height=65, x=4, y=7)

        self.ent8 = Entry(self.f6, bd=0, bg='#EBE7D9', fg='#342F4B', justify='left', font='Lato 14')
        self.ent8.place(width=263, height=25, x=363, y=164)

        self.b12 = Button(self.f6, bd=0, image=self.bConfir)
        self.b12.place(width=275, height=80, x=360, y=494)

        self.bt1 = Button(self.f6, bd=0, image=self.bPesquisa)
        self.bt1.place(width=48, height=34, x=592, y=160)


        self.window.mainloop()

    #================| Funções |=====================
    def tMenu(self):
        self.f1.forget()
        self.f2.pack()

    def tCadastro(self):
        self.f2.forget()
        self.f3.pack()

    def tAlterar(self):
        self.f2.forget()
        self.f4.pack()

    def tAlterar2(self):
        self.f4.forget()
        self.f5.pack()

    def tExcluir(self):
        self.f2.forget()
        self.f6.pack()


janela = Modulo1()