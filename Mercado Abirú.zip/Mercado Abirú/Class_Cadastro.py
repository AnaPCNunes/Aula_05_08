import mysql.connector
from Class_Produto import *

class Cadastro:
    def __init__(self):
        self.conexao = mysql.connector.connect(host='localhost', user='root', password='q1w2e3', database='mercado')
        self.cursorzinho = self.conexao.cursor()
        self.list = []

    # Create
    def cadastrar_produtos(self, cod, descricao, valor, quantidade):
        obj_produto = Produto(cod, descricao, valor, quantidade)
        comando_sql = f'insert into Produto (descricao, valor, quantidade) value ("{obj_produto.descricao}", "{obj_produto.valor}", {obj_produto.quantidade})'
        self.cursorzinho.execute(comando_sql)
        self.conexao.commit()
        print('\nProduto cadastrado com sucesso!\n')
            
    # Update
    def alterar_informacoes(self, atributo, info, codi):
        comando_sql = f'update Produto set {atributo} = "{info}" where cod = {codi}'
        try:
            self.cursorzinho.execute(comando_sql)
            self.conexao.commit()
        except:
            print('\nCódigo não encontrado!\n')
        
    # Delete
    def excluir_cadastro(self, codi):
        comando_sql = f'delete from Produto where cod = {codi}'
        try:
            self.cursorzinho.execute(comando_sql)
            self.conexao.commit()
        except:
            print('\nCódigo não encontrado!\n')


    def listar_produtos(self, codig):
        
        
        if codig != '':
            comando_sql = f'select Produto.cod, Produto.descricao, Produto.valor, Produto.quantidade from Produto where Produto.cod = {codig}'
            self.cursorzinho.execute(comando_sql)
            selecao = self.cursorzinho.fetchall()
            for i in selecao:
                exib = (f' {i} ').replace(',',' | ').replace("'",'♦').replace('(','╠').replace(')','╣')
                return exib           
     




